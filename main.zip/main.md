# 1. Installing Dependencies and Setup


```python
from IPython.display import Image, display

# Specify the path to the image file or use the filename if it's in the same directory.
image_path = 'D:\Waste-classifier/cpu config tflow.png'

# Display the image in the Jupyter Notebook
display(Image(filename=image_path))
```


    
![png](output_1_0.png)
    



```python
pip install tensorflow==2.12.0
```

    Requirement already satisfied: tensorflow==2.12.0 in d:\waste-classifier\wasteclassification\lib\site-packages (2.12.0)
    Requirement already satisfied: tensorflow-intel==2.12.0 in d:\waste-classifier\wasteclassification\lib\site-packages (from tensorflow==2.12.0) (2.12.0)
    Requirement already satisfied: gast<=0.4.0,>=0.2.1 in d:\waste-classifier\wasteclassification\lib\site-packages (from tensorflow-intel==2.12.0->tensorflow==2.12.0) (0.4.0)
    Requirement already satisfied: libclang>=13.0.0 in d:\waste-classifier\wasteclassification\lib\site-packages (from tensorflow-intel==2.12.0->tensorflow==2.12.0) (16.0.6)
    Collecting protobuf!=4.21.0,!=4.21.1,!=4.21.2,!=4.21.3,!=4.21.4,!=4.21.5,<5.0.0dev,>=3.20.3
      Downloading protobuf-4.24.2-cp310-abi3-win_amd64.whl (430 kB)
         ------------------------------------ 430.4/430.4 kB 584.4 kB/s eta 0:00:00
    Collecting keras<2.13,>=2.12.0
      Using cached keras-2.12.0-py2.py3-none-any.whl (1.7 MB)
    Requirement already satisfied: absl-py>=1.0.0 in d:\waste-classifier\wasteclassification\lib\site-packages (from tensorflow-intel==2.12.0->tensorflow==2.12.0) (1.4.0)
    Requirement already satisfied: packaging in d:\waste-classifier\wasteclassification\lib\site-packages (from tensorflow-intel==2.12.0->tensorflow==2.12.0) (23.1)
    Requirement already satisfied: h5py>=2.9.0 in d:\waste-classifier\wasteclassification\lib\site-packages (from tensorflow-intel==2.12.0->tensorflow==2.12.0) (3.9.0)
    Requirement already satisfied: tensorflow-io-gcs-filesystem>=0.23.1 in d:\waste-classifier\wasteclassification\lib\site-packages (from tensorflow-intel==2.12.0->tensorflow==2.12.0) (0.31.0)
    Collecting tensorboard<2.13,>=2.12
      Using cached tensorboard-2.12.3-py3-none-any.whl (5.6 MB)
    Requirement already satisfied: setuptools in d:\waste-classifier\wasteclassification\lib\site-packages (from tensorflow-intel==2.12.0->tensorflow==2.12.0) (63.2.0)
    Requirement already satisfied: grpcio<2.0,>=1.24.3 in d:\waste-classifier\wasteclassification\lib\site-packages (from tensorflow-intel==2.12.0->tensorflow==2.12.0) (1.56.2)
    Requirement already satisfied: six>=1.12.0 in d:\waste-classifier\wasteclassification\lib\site-packages (from tensorflow-intel==2.12.0->tensorflow==2.12.0) (1.16.0)
    Requirement already satisfied: termcolor>=1.1.0 in d:\waste-classifier\wasteclassification\lib\site-packages (from tensorflow-intel==2.12.0->tensorflow==2.12.0) (2.3.0)
    Collecting tensorflow-estimator<2.13,>=2.12.0
      Using cached tensorflow_estimator-2.12.0-py2.py3-none-any.whl (440 kB)
    Requirement already satisfied: jax>=0.3.15 in d:\waste-classifier\wasteclassification\lib\site-packages (from tensorflow-intel==2.12.0->tensorflow==2.12.0) (0.4.14)
    Requirement already satisfied: opt-einsum>=2.3.2 in d:\waste-classifier\wasteclassification\lib\site-packages (from tensorflow-intel==2.12.0->tensorflow==2.12.0) (3.3.0)
    Requirement already satisfied: wrapt<1.15,>=1.11.0 in d:\waste-classifier\wasteclassification\lib\site-packages (from tensorflow-intel==2.12.0->tensorflow==2.12.0) (1.14.1)
    Requirement already satisfied: typing-extensions>=3.6.6 in d:\waste-classifier\wasteclassification\lib\site-packages (from tensorflow-intel==2.12.0->tensorflow==2.12.0) (4.7.1)
    Requirement already satisfied: astunparse>=1.6.0 in d:\waste-classifier\wasteclassification\lib\site-packages (from tensorflow-intel==2.12.0->tensorflow==2.12.0) (1.6.3)
    Requirement already satisfied: flatbuffers>=2.0 in d:\waste-classifier\wasteclassification\lib\site-packages (from tensorflow-intel==2.12.0->tensorflow==2.12.0) (23.5.26)
    Requirement already satisfied: numpy<1.24,>=1.22 in d:\waste-classifier\wasteclassification\lib\site-packages (from tensorflow-intel==2.12.0->tensorflow==2.12.0) (1.23.5)
    Requirement already satisfied: google-pasta>=0.1.1 in d:\waste-classifier\wasteclassification\lib\site-packages (from tensorflow-intel==2.12.0->tensorflow==2.12.0) (0.2.0)
    Requirement already satisfied: wheel<1.0,>=0.23.0 in d:\waste-classifier\wasteclassification\lib\site-packages (from astunparse>=1.6.0->tensorflow-intel==2.12.0->tensorflow==2.12.0) (0.41.0)
    Requirement already satisfied: ml-dtypes>=0.2.0 in d:\waste-classifier\wasteclassification\lib\site-packages (from jax>=0.3.15->tensorflow-intel==2.12.0->tensorflow==2.12.0) (0.2.0)
    Requirement already satisfied: scipy>=1.7 in d:\waste-classifier\wasteclassification\lib\site-packages (from jax>=0.3.15->tensorflow-intel==2.12.0->tensorflow==2.12.0) (1.11.1)
    Collecting google-auth-oauthlib<1.1,>=0.5
      Using cached google_auth_oauthlib-1.0.0-py2.py3-none-any.whl (18 kB)
    Requirement already satisfied: markdown>=2.6.8 in d:\waste-classifier\wasteclassification\lib\site-packages (from tensorboard<2.13,>=2.12->tensorflow-intel==2.12.0->tensorflow==2.12.0) (3.4.4)
    Collecting tensorboard-data-server<0.8.0,>=0.7.0
      Using cached tensorboard_data_server-0.7.1-py3-none-any.whl (2.4 kB)
    Requirement already satisfied: requests<3,>=2.21.0 in d:\waste-classifier\wasteclassification\lib\site-packages (from tensorboard<2.13,>=2.12->tensorflow-intel==2.12.0->tensorflow==2.12.0) (2.31.0)
    Requirement already satisfied: werkzeug>=1.0.1 in d:\waste-classifier\wasteclassification\lib\site-packages (from tensorboard<2.13,>=2.12->tensorflow-intel==2.12.0->tensorflow==2.12.0) (2.3.6)
    Requirement already satisfied: google-auth<3,>=1.6.3 in d:\waste-classifier\wasteclassification\lib\site-packages (from tensorboard<2.13,>=2.12->tensorflow-intel==2.12.0->tensorflow==2.12.0) (2.22.0)
    Requirement already satisfied: urllib3<2.0 in d:\waste-classifier\wasteclassification\lib\site-packages (from google-auth<3,>=1.6.3->tensorboard<2.13,>=2.12->tensorflow-intel==2.12.0->tensorflow==2.12.0) (1.26.16)
    Requirement already satisfied: pyasn1-modules>=0.2.1 in d:\waste-classifier\wasteclassification\lib\site-packages (from google-auth<3,>=1.6.3->tensorboard<2.13,>=2.12->tensorflow-intel==2.12.0->tensorflow==2.12.0) (0.3.0)
    Requirement already satisfied: cachetools<6.0,>=2.0.0 in d:\waste-classifier\wasteclassification\lib\site-packages (from google-auth<3,>=1.6.3->tensorboard<2.13,>=2.12->tensorflow-intel==2.12.0->tensorflow==2.12.0) (5.3.1)
    Requirement already satisfied: rsa<5,>=3.1.4 in d:\waste-classifier\wasteclassification\lib\site-packages (from google-auth<3,>=1.6.3->tensorboard<2.13,>=2.12->tensorflow-intel==2.12.0->tensorflow==2.12.0) (4.9)
    Requirement already satisfied: requests-oauthlib>=0.7.0 in d:\waste-classifier\wasteclassification\lib\site-packages (from google-auth-oauthlib<1.1,>=0.5->tensorboard<2.13,>=2.12->tensorflow-intel==2.12.0->tensorflow==2.12.0) (1.3.1)
    Requirement already satisfied: charset-normalizer<4,>=2 in d:\waste-classifier\wasteclassification\lib\site-packages (from requests<3,>=2.21.0->tensorboard<2.13,>=2.12->tensorflow-intel==2.12.0->tensorflow==2.12.0) (3.2.0)
    Requirement already satisfied: idna<4,>=2.5 in d:\waste-classifier\wasteclassification\lib\site-packages (from requests<3,>=2.21.0->tensorboard<2.13,>=2.12->tensorflow-intel==2.12.0->tensorflow==2.12.0) (3.4)
    Requirement already satisfied: certifi>=2017.4.17 in d:\waste-classifier\wasteclassification\lib\site-packages (from requests<3,>=2.21.0->tensorboard<2.13,>=2.12->tensorflow-intel==2.12.0->tensorflow==2.12.0) (2023.7.22)
    Requirement already satisfied: MarkupSafe>=2.1.1 in d:\waste-classifier\wasteclassification\lib\site-packages (from werkzeug>=1.0.1->tensorboard<2.13,>=2.12->tensorflow-intel==2.12.0->tensorflow==2.12.0) (2.1.3)
    Requirement already satisfied: pyasn1<0.6.0,>=0.4.6 in d:\waste-classifier\wasteclassification\lib\site-packages (from pyasn1-modules>=0.2.1->google-auth<3,>=1.6.3->tensorboard<2.13,>=2.12->tensorflow-intel==2.12.0->tensorflow==2.12.0) (0.5.0)
    Requirement already satisfied: oauthlib>=3.0.0 in d:\waste-classifier\wasteclassification\lib\site-packages (from requests-oauthlib>=0.7.0->google-auth-oauthlib<1.1,>=0.5->tensorboard<2.13,>=2.12->tensorflow-intel==2.12.0->tensorflow==2.12.0) (3.2.2)
    Installing collected packages: tensorflow-estimator, tensorboard-data-server, protobuf, keras, google-auth-oauthlib, tensorboard
      Attempting uninstall: tensorflow-estimator
        Found existing installation: tensorflow-estimator 2.10.0
        Uninstalling tensorflow-estimator-2.10.0:
          Successfully uninstalled tensorflow-estimator-2.10.0
      Attempting uninstall: tensorboard-data-server
        Found existing installation: tensorboard-data-server 0.6.1
        Uninstalling tensorboard-data-server-0.6.1:
          Successfully uninstalled tensorboard-data-server-0.6.1
      Attempting uninstall: protobuf
        Found existing installation: protobuf 3.19.6
        Uninstalling protobuf-3.19.6:
          Successfully uninstalled protobuf-3.19.6
      Attempting uninstall: keras
        Found existing installation: keras 2.10.0
        Uninstalling keras-2.10.0:
          Successfully uninstalled keras-2.10.0
      Attempting uninstall: google-auth-oauthlib
        Found existing installation: google-auth-oauthlib 0.4.6
        Uninstalling google-auth-oauthlib-0.4.6:
          Successfully uninstalled google-auth-oauthlib-0.4.6
      Attempting uninstall: tensorboard
        Found existing installation: tensorboard 2.10.1
        Uninstalling tensorboard-2.10.1:
          Successfully uninstalled tensorboard-2.10.1
    Successfully installed google-auth-oauthlib-1.0.0 keras-2.12.0 protobuf-4.24.2 tensorboard-2.12.3 tensorboard-data-server-0.7.1 tensorflow-estimator-2.12.0
    Note: you may need to restart the kernel to use updated packages.
    

    WARNING: Ignoring invalid distribution -rotobuf (d:\waste-classifier\wasteclassification\lib\site-packages)
    WARNING: Ignoring invalid distribution -rotobuf (d:\waste-classifier\wasteclassification\lib\site-packages)
    WARNING: Ignoring invalid distribution -rotobuf (d:\waste-classifier\wasteclassification\lib\site-packages)
        WARNING: Ignoring invalid distribution -rotobuf (d:\waste-classifier\wasteclassification\lib\site-packages)
        WARNING: Ignoring invalid distribution -rotobuf (d:\waste-classifier\wasteclassification\lib\site-packages)
        WARNING: Ignoring invalid distribution -rotobuf (d:\waste-classifier\wasteclassification\lib\site-packages)
        WARNING: Ignoring invalid distribution -rotobuf (d:\waste-classifier\wasteclassification\lib\site-packages)
        WARNING: Ignoring invalid distribution -rotobuf (d:\waste-classifier\wasteclassification\lib\site-packages)
        WARNING: Ignoring invalid distribution -rotobuf (d:\waste-classifier\wasteclassification\lib\site-packages)
    WARNING: Ignoring invalid distribution -rotobuf (d:\waste-classifier\wasteclassification\lib\site-packages)
    WARNING: Ignoring invalid distribution -rotobuf (d:\waste-classifier\wasteclassification\lib\site-packages)
    WARNING: Ignoring invalid distribution -rotobuf (d:\waste-classifier\wasteclassification\lib\site-packages)
    WARNING: Ignoring invalid distribution -rotobuf (d:\waste-classifier\wasteclassification\lib\site-packages)
    WARNING: Ignoring invalid distribution -rotobuf (d:\waste-classifier\wasteclassification\lib\site-packages)
    WARNING: Ignoring invalid distribution -rotobuf (d:\waste-classifier\wasteclassification\lib\site-packages)
    ERROR: pip's dependency resolver does not currently take into account all the packages that are installed. This behaviour is the source of the following dependency conflicts.
    tensorflow-gpu 2.10.0 requires keras<2.11,>=2.10.0, but you have keras 2.12.0 which is incompatible.
    tensorflow-gpu 2.10.0 requires protobuf<3.20,>=3.9.2, but you have protobuf 4.24.2 which is incompatible.
    tensorflow-gpu 2.10.0 requires tensorboard<2.11,>=2.10, but you have tensorboard 2.12.3 which is incompatible.
    tensorflow-gpu 2.10.0 requires tensorflow-estimator<2.11,>=2.10.0, but you have tensorflow-estimator 2.12.0 which is incompatible.
    WARNING: Ignoring invalid distribution -rotobuf (d:\waste-classifier\wasteclassification\lib\site-packages)
    WARNING: Ignoring invalid distribution -rotobuf (d:\waste-classifier\wasteclassification\lib\site-packages)
    WARNING: Ignoring invalid distribution -rotobuf (d:\waste-classifier\wasteclassification\lib\site-packages)
    
    [notice] A new release of pip available: 22.2.1 -> 23.2.1
    [notice] To update, run: D:\Waste-classifier\wasteclassification\Scripts\python.exe -m pip install --upgrade pip
    


```python
pip install keras==2.10.0
```

    Collecting keras==2.10.0
      Using cached keras-2.10.0-py2.py3-none-any.whl (1.7 MB)
    Installing collected packages: keras
      Attempting uninstall: keras
        Found existing installation: keras 2.12.0
        Uninstalling keras-2.12.0:
          Successfully uninstalled keras-2.12.0
    Successfully installed keras-2.10.0
    Note: you may need to restart the kernel to use updated packages.
    

    WARNING: Ignoring invalid distribution -rotobuf (d:\waste-classifier\wasteclassification\lib\site-packages)
    WARNING: Ignoring invalid distribution -rotobuf (d:\waste-classifier\wasteclassification\lib\site-packages)
    WARNING: Ignoring invalid distribution -rotobuf (d:\waste-classifier\wasteclassification\lib\site-packages)
        WARNING: Ignoring invalid distribution -rotobuf (d:\waste-classifier\wasteclassification\lib\site-packages)
    WARNING: Ignoring invalid distribution -rotobuf (d:\waste-classifier\wasteclassification\lib\site-packages)
    ERROR: pip's dependency resolver does not currently take into account all the packages that are installed. This behaviour is the source of the following dependency conflicts.
    tensorflow-intel 2.12.0 requires keras<2.13,>=2.12.0, but you have keras 2.10.0 which is incompatible.
    tensorflow-gpu 2.10.0 requires protobuf<3.20,>=3.9.2, but you have protobuf 4.24.2 which is incompatible.
    tensorflow-gpu 2.10.0 requires tensorboard<2.11,>=2.10, but you have tensorboard 2.12.3 which is incompatible.
    tensorflow-gpu 2.10.0 requires tensorflow-estimator<2.11,>=2.10.0, but you have tensorflow-estimator 2.12.0 which is incompatible.
    WARNING: Ignoring invalid distribution -rotobuf (d:\waste-classifier\wasteclassification\lib\site-packages)
    WARNING: Ignoring invalid distribution -rotobuf (d:\waste-classifier\wasteclassification\lib\site-packages)
    WARNING: Ignoring invalid distribution -rotobuf (d:\waste-classifier\wasteclassification\lib\site-packages)
    
    [notice] A new release of pip available: 22.2.1 -> 23.2.1
    [notice] To update, run: D:\Waste-classifier\wasteclassification\Scripts\python.exe -m pip install --upgrade pip
    


```python
from IPython.display import Image, display

# Specify the path to the image file or use the filename if it's in the same directory.
image_path = 'D:\Waste-classifier/gpu config tflow.png'

# Display the image in the Jupyter Notebook
display(Image(filename=image_path))

```


    
![png](output_4_0.png)
    



```python
pip install tensorflow-gpu==2.10.0
```

    Requirement already satisfied: tensorflow-gpu==2.10.0 in d:\waste-classifier\wasteclassification\lib\site-packages (2.10.0)Note: you may need to restart the kernel to use updated packages.
    
    Requirement already satisfied: libclang>=13.0.0 in d:\waste-classifier\wasteclassification\lib\site-packages (from tensorflow-gpu==2.10.0) (16.0.6)
    Collecting tensorflow-estimator<2.11,>=2.10.0
      Using cached tensorflow_estimator-2.10.0-py2.py3-none-any.whl (438 kB)
    Requirement already satisfied: setuptools in d:\waste-classifier\wasteclassification\lib\site-packages (from tensorflow-gpu==2.10.0) (63.2.0)
    Requirement already satisfied: grpcio<2.0,>=1.24.3 in d:\waste-classifier\wasteclassification\lib\site-packages (from tensorflow-gpu==2.10.0) (1.56.2)
    Requirement already satisfied: tensorflow-io-gcs-filesystem>=0.23.1 in d:\waste-classifier\wasteclassification\lib\site-packages (from tensorflow-gpu==2.10.0) (0.31.0)
    Requirement already satisfied: keras<2.11,>=2.10.0 in d:\waste-classifier\wasteclassification\lib\site-packages (from tensorflow-gpu==2.10.0) (2.10.0)
    Requirement already satisfied: google-pasta>=0.1.1 in d:\waste-classifier\wasteclassification\lib\site-packages (from tensorflow-gpu==2.10.0) (0.2.0)
    Requirement already satisfied: flatbuffers>=2.0 in d:\waste-classifier\wasteclassification\lib\site-packages (from tensorflow-gpu==2.10.0) (23.5.26)
    Requirement already satisfied: gast<=0.4.0,>=0.2.1 in d:\waste-classifier\wasteclassification\lib\site-packages (from tensorflow-gpu==2.10.0) (0.4.0)
    Requirement already satisfied: six>=1.12.0 in d:\waste-classifier\wasteclassification\lib\site-packages (from tensorflow-gpu==2.10.0) (1.16.0)
    Requirement already satisfied: opt-einsum>=2.3.2 in d:\waste-classifier\wasteclassification\lib\site-packages (from tensorflow-gpu==2.10.0) (3.3.0)
    Requirement already satisfied: keras-preprocessing>=1.1.1 in d:\waste-classifier\wasteclassification\lib\site-packages (from tensorflow-gpu==2.10.0) (1.1.2)
    Requirement already satisfied: h5py>=2.9.0 in d:\waste-classifier\wasteclassification\lib\site-packages (from tensorflow-gpu==2.10.0) (3.9.0)
    Requirement already satisfied: typing-extensions>=3.6.6 in d:\waste-classifier\wasteclassification\lib\site-packages (from tensorflow-gpu==2.10.0) (4.7.1)
    Requirement already satisfied: numpy>=1.20 in d:\waste-classifier\wasteclassification\lib\site-packages (from tensorflow-gpu==2.10.0) (1.23.5)
    Requirement already satisfied: absl-py>=1.0.0 in d:\waste-classifier\wasteclassification\lib\site-packages (from tensorflow-gpu==2.10.0) (1.4.0)
    Requirement already satisfied: termcolor>=1.1.0 in d:\waste-classifier\wasteclassification\lib\site-packages (from tensorflow-gpu==2.10.0) (2.3.0)
    Requirement already satisfied: packaging in d:\waste-classifier\wasteclassification\lib\site-packages (from tensorflow-gpu==2.10.0) (23.1)
    Requirement already satisfied: wrapt>=1.11.0 in d:\waste-classifier\wasteclassification\lib\site-packages (from tensorflow-gpu==2.10.0) (1.14.1)
    Collecting protobuf<3.20,>=3.9.2
      Using cached protobuf-3.19.6-cp310-cp310-win_amd64.whl (895 kB)
    Collecting tensorboard<2.11,>=2.10
      Using cached tensorboard-2.10.1-py3-none-any.whl (5.9 MB)
    Requirement already satisfied: astunparse>=1.6.0 in d:\waste-classifier\wasteclassification\lib\site-packages (from tensorflow-gpu==2.10.0) (1.6.3)
    Requirement already satisfied: wheel<1.0,>=0.23.0 in d:\waste-classifier\wasteclassification\lib\site-packages (from astunparse>=1.6.0->tensorflow-gpu==2.10.0) (0.41.0)
    Requirement already satisfied: markdown>=2.6.8 in d:\waste-classifier\wasteclassification\lib\site-packages (from tensorboard<2.11,>=2.10->tensorflow-gpu==2.10.0) (3.4.4)
    Requirement already satisfied: requests<3,>=2.21.0 in d:\waste-classifier\wasteclassification\lib\site-packages (from tensorboard<2.11,>=2.10->tensorflow-gpu==2.10.0) (2.31.0)
    Collecting tensorboard-data-server<0.7.0,>=0.6.0
      Using cached tensorboard_data_server-0.6.1-py3-none-any.whl (2.4 kB)
    Requirement already satisfied: tensorboard-plugin-wit>=1.6.0 in d:\waste-classifier\wasteclassification\lib\site-packages (from tensorboard<2.11,>=2.10->tensorflow-gpu==2.10.0) (1.8.1)
    Requirement already satisfied: google-auth<3,>=1.6.3 in d:\waste-classifier\wasteclassification\lib\site-packages (from tensorboard<2.11,>=2.10->tensorflow-gpu==2.10.0) (2.22.0)
    Collecting google-auth-oauthlib<0.5,>=0.4.1
      Using cached google_auth_oauthlib-0.4.6-py2.py3-none-any.whl (18 kB)
    Requirement already satisfied: werkzeug>=1.0.1 in d:\waste-classifier\wasteclassification\lib\site-packages (from tensorboard<2.11,>=2.10->tensorflow-gpu==2.10.0) (2.3.6)
    Requirement already satisfied: cachetools<6.0,>=2.0.0 in d:\waste-classifier\wasteclassification\lib\site-packages (from google-auth<3,>=1.6.3->tensorboard<2.11,>=2.10->tensorflow-gpu==2.10.0) (5.3.1)
    Requirement already satisfied: rsa<5,>=3.1.4 in d:\waste-classifier\wasteclassification\lib\site-packages (from google-auth<3,>=1.6.3->tensorboard<2.11,>=2.10->tensorflow-gpu==2.10.0) (4.9)
    Requirement already satisfied: urllib3<2.0 in d:\waste-classifier\wasteclassification\lib\site-packages (from google-auth<3,>=1.6.3->tensorboard<2.11,>=2.10->tensorflow-gpu==2.10.0) (1.26.16)
    Requirement already satisfied: pyasn1-modules>=0.2.1 in d:\waste-classifier\wasteclassification\lib\site-packages (from google-auth<3,>=1.6.3->tensorboard<2.11,>=2.10->tensorflow-gpu==2.10.0) (0.3.0)
    Requirement already satisfied: requests-oauthlib>=0.7.0 in d:\waste-classifier\wasteclassification\lib\site-packages (from google-auth-oauthlib<0.5,>=0.4.1->tensorboard<2.11,>=2.10->tensorflow-gpu==2.10.0) (1.3.1)
    Requirement already satisfied: certifi>=2017.4.17 in d:\waste-classifier\wasteclassification\lib\site-packages (from requests<3,>=2.21.0->tensorboard<2.11,>=2.10->tensorflow-gpu==2.10.0) (2023.7.22)
    Requirement already satisfied: idna<4,>=2.5 in d:\waste-classifier\wasteclassification\lib\site-packages (from requests<3,>=2.21.0->tensorboard<2.11,>=2.10->tensorflow-gpu==2.10.0) (3.4)
    Requirement already satisfied: charset-normalizer<4,>=2 in d:\waste-classifier\wasteclassification\lib\site-packages (from requests<3,>=2.21.0->tensorboard<2.11,>=2.10->tensorflow-gpu==2.10.0) (3.2.0)
    Requirement already satisfied: MarkupSafe>=2.1.1 in d:\waste-classifier\wasteclassification\lib\site-packages (from werkzeug>=1.0.1->tensorboard<2.11,>=2.10->tensorflow-gpu==2.10.0) (2.1.3)
    Requirement already satisfied: pyasn1<0.6.0,>=0.4.6 in d:\waste-classifier\wasteclassification\lib\site-packages (from pyasn1-modules>=0.2.1->google-auth<3,>=1.6.3->tensorboard<2.11,>=2.10->tensorflow-gpu==2.10.0) (0.5.0)
    Requirement already satisfied: oauthlib>=3.0.0 in d:\waste-classifier\wasteclassification\lib\site-packages (from requests-oauthlib>=0.7.0->google-auth-oauthlib<0.5,>=0.4.1->tensorboard<2.11,>=2.10->tensorflow-gpu==2.10.0) (3.2.2)
    Installing collected packages: tensorflow-estimator, tensorboard-data-server, protobuf, google-auth-oauthlib, tensorboard
      Attempting uninstall: tensorflow-estimator
        Found existing installation: tensorflow-estimator 2.12.0
        Uninstalling tensorflow-estimator-2.12.0:
          Successfully uninstalled tensorflow-estimator-2.12.0
      Attempting uninstall: tensorboard-data-server
        Found existing installation: tensorboard-data-server 0.7.1
        Uninstalling tensorboard-data-server-0.7.1:
          Successfully uninstalled tensorboard-data-server-0.7.1
      Attempting uninstall: protobuf
        Found existing installation: protobuf 4.24.2
        Uninstalling protobuf-4.24.2:
          Successfully uninstalled protobuf-4.24.2
      Attempting uninstall: google-auth-oauthlib
        Found existing installation: google-auth-oauthlib 1.0.0
        Uninstalling google-auth-oauthlib-1.0.0:
          Successfully uninstalled google-auth-oauthlib-1.0.0
      Attempting uninstall: tensorboard
        Found existing installation: tensorboard 2.12.3
        Uninstalling tensorboard-2.12.3:
          Successfully uninstalled tensorboard-2.12.3
    Successfully installed google-auth-oauthlib-0.4.6 protobuf-3.19.6 tensorboard-2.10.1 tensorboard-data-server-0.6.1 tensorflow-estimator-2.10.0
    

    WARNING: Ignoring invalid distribution -rotobuf (d:\waste-classifier\wasteclassification\lib\site-packages)
    WARNING: Ignoring invalid distribution -rotobuf (d:\waste-classifier\wasteclassification\lib\site-packages)
    WARNING: Ignoring invalid distribution -rotobuf (d:\waste-classifier\wasteclassification\lib\site-packages)
        WARNING: Ignoring invalid distribution -rotobuf (d:\waste-classifier\wasteclassification\lib\site-packages)
        WARNING: Ignoring invalid distribution -rotobuf (d:\waste-classifier\wasteclassification\lib\site-packages)
        WARNING: Ignoring invalid distribution -rotobuf (d:\waste-classifier\wasteclassification\lib\site-packages)
        WARNING: Ignoring invalid distribution -rotobuf (d:\waste-classifier\wasteclassification\lib\site-packages)
        WARNING: Ignoring invalid distribution -rotobuf (d:\waste-classifier\wasteclassification\lib\site-packages)
    WARNING: Ignoring invalid distribution -rotobuf (d:\waste-classifier\wasteclassification\lib\site-packages)
    WARNING: Ignoring invalid distribution -rotobuf (d:\waste-classifier\wasteclassification\lib\site-packages)
    WARNING: Ignoring invalid distribution -rotobuf (d:\waste-classifier\wasteclassification\lib\site-packages)
    WARNING: Ignoring invalid distribution -rotobuf (d:\waste-classifier\wasteclassification\lib\site-packages)
    WARNING: Ignoring invalid distribution -rotobuf (d:\waste-classifier\wasteclassification\lib\site-packages)
    ERROR: pip's dependency resolver does not currently take into account all the packages that are installed. This behaviour is the source of the following dependency conflicts.
    tensorflow-intel 2.12.0 requires keras<2.13,>=2.12.0, but you have keras 2.10.0 which is incompatible.
    tensorflow-intel 2.12.0 requires protobuf!=4.21.0,!=4.21.1,!=4.21.2,!=4.21.3,!=4.21.4,!=4.21.5,<5.0.0dev,>=3.20.3, but you have protobuf 3.19.6 which is incompatible.
    tensorflow-intel 2.12.0 requires tensorboard<2.13,>=2.12, but you have tensorboard 2.10.1 which is incompatible.
    tensorflow-intel 2.12.0 requires tensorflow-estimator<2.13,>=2.12.0, but you have tensorflow-estimator 2.10.0 which is incompatible.
    WARNING: Ignoring invalid distribution -rotobuf (d:\waste-classifier\wasteclassification\lib\site-packages)
    WARNING: Ignoring invalid distribution -rotobuf (d:\waste-classifier\wasteclassification\lib\site-packages)
    WARNING: Ignoring invalid distribution -rotobuf (d:\waste-classifier\wasteclassification\lib\site-packages)
    
    [notice] A new release of pip available: 22.2.1 -> 23.2.1
    [notice] To update, run: D:\Waste-classifier\wasteclassification\Scripts\python.exe -m pip install --upgrade pip
    


```python
pip install opencv-python
```

    Requirement already satisfied: opencv-python in d:\waste-classifier\wasteclassification\lib\site-packages (4.8.0.74)
    Requirement already satisfied: numpy>=1.17.0 in d:\waste-classifier\wasteclassification\lib\site-packages (from opencv-python) (1.23.5)
    Note: you may need to restart the kernel to use updated packages.
    

    WARNING: Ignoring invalid distribution -rotobuf (d:\waste-classifier\wasteclassification\lib\site-packages)
    WARNING: Ignoring invalid distribution -rotobuf (d:\waste-classifier\wasteclassification\lib\site-packages)
    WARNING: Ignoring invalid distribution -rotobuf (d:\waste-classifier\wasteclassification\lib\site-packages)
    WARNING: Ignoring invalid distribution -rotobuf (d:\waste-classifier\wasteclassification\lib\site-packages)
    WARNING: Ignoring invalid distribution -rotobuf (d:\waste-classifier\wasteclassification\lib\site-packages)
    WARNING: Ignoring invalid distribution -rotobuf (d:\waste-classifier\wasteclassification\lib\site-packages)
    
    [notice] A new release of pip available: 22.2.1 -> 23.2.1
    [notice] To update, run: D:\Waste-classifier\wasteclassification\Scripts\python.exe -m pip install --upgrade pip
    


```python
pip install matplotlib
```

    Requirement already satisfied: matplotlib in d:\waste-classifier\wasteclassification\lib\site-packages (3.7.2)
    Requirement already satisfied: python-dateutil>=2.7 in d:\waste-classifier\wasteclassification\lib\site-packages (from matplotlib) (2.8.2)
    Requirement already satisfied: packaging>=20.0 in d:\waste-classifier\wasteclassification\lib\site-packages (from matplotlib) (23.1)
    Requirement already satisfied: pillow>=6.2.0 in d:\waste-classifier\wasteclassification\lib\site-packages (from matplotlib) (10.0.0)
    Requirement already satisfied: kiwisolver>=1.0.1 in d:\waste-classifier\wasteclassification\lib\site-packages (from matplotlib) (1.4.4)
    Requirement already satisfied: fonttools>=4.22.0 in d:\waste-classifier\wasteclassification\lib\site-packages (from matplotlib) (4.41.1)
    Requirement already satisfied: numpy>=1.20 in d:\waste-classifier\wasteclassification\lib\site-packages (from matplotlib) (1.23.5)
    Requirement already satisfied: pyparsing<3.1,>=2.3.1 in d:\waste-classifier\wasteclassification\lib\site-packages (from matplotlib) (3.0.9)
    Requirement already satisfied: contourpy>=1.0.1 in d:\waste-classifier\wasteclassification\lib\site-packages (from matplotlib) (1.1.0)
    Requirement already satisfied: cycler>=0.10 in d:\waste-classifier\wasteclassification\lib\site-packages (from matplotlib) (0.11.0)
    Requirement already satisfied: six>=1.5 in d:\waste-classifier\wasteclassification\lib\site-packages (from python-dateutil>=2.7->matplotlib) (1.16.0)
    Note: you may need to restart the kernel to use updated packages.
    

    WARNING: Ignoring invalid distribution -rotobuf (d:\waste-classifier\wasteclassification\lib\site-packages)
    WARNING: Ignoring invalid distribution -rotobuf (d:\waste-classifier\wasteclassification\lib\site-packages)
    WARNING: Ignoring invalid distribution -rotobuf (d:\waste-classifier\wasteclassification\lib\site-packages)
    WARNING: Ignoring invalid distribution -rotobuf (d:\waste-classifier\wasteclassification\lib\site-packages)
    WARNING: Ignoring invalid distribution -rotobuf (d:\waste-classifier\wasteclassification\lib\site-packages)
    WARNING: Ignoring invalid distribution -rotobuf (d:\waste-classifier\wasteclassification\lib\site-packages)
    
    [notice] A new release of pip available: 22.2.1 -> 23.2.1
    [notice] To update, run: D:\Waste-classifier\wasteclassification\Scripts\python.exe -m pip install --upgrade pip
    


```python
!pip list
```

    
    [notice] A new release of pip is available: 23.2 -> 23.2.1
    [notice] To update, run: python.exe -m pip install --upgrade pip
    

    Package                      Version
    ---------------------------- --------
    absl-py                      1.4.0
    anyio                        3.7.0
    argon2-cffi                  21.3.0
    argon2-cffi-bindings         21.2.0
    arrow                        1.2.3
    asttokens                    2.2.1
    astunparse                   1.6.3
    async-lru                    2.0.2
    attrs                        23.1.0
    Babel                        2.12.1
    backcall                     0.2.0
    beautifulsoup4               4.9.3
    bleach                       6.0.0
    cachetools                   5.3.1
    certifi                      2023.5.7
    cffi                         1.15.1
    charset-normalizer           3.1.0
    click                        8.1.3
    colorama                     0.4.5
    comm                         0.1.3
    contourpy                    1.1.0
    cryptography                 41.0.0
    cycler                       0.11.0
    debugpy                      1.6.7
    decorator                    5.1.1
    defusedxml                   0.7.1
    exceptiongroup               1.1.1
    executing                    1.2.0
    fastjsonschema               2.17.1
    Flask                        2.2.2
    flatbuffers                  23.5.26
    fonttools                    4.41.1
    fqdn                         1.5.1
    gast                         0.4.0
    google-auth                  2.22.0
    google-auth-oauthlib         1.0.0
    google-pasta                 0.2.0
    grpcio                       1.56.0
    h5py                         3.9.0
    idna                         3.4
    ipykernel                    6.22.0
    ipython                      8.13.2
    ipython-genutils             0.2.0
    ipywidgets                   8.0.7
    isoduration                  20.11.0
    itsdangerous                 2.1.2
    jedi                         0.18.2
    Jinja2                       3.1.2
    json5                        0.9.14
    jsonpointer                  2.4
    jsonschema                   4.17.3
    jupyter                      1.0.0
    jupyter_client               8.2.0
    jupyter-console              6.6.3
    jupyter_core                 5.3.0
    jupyter-events               0.6.3
    jupyter-lsp                  2.2.0
    jupyter_server               2.7.0
    jupyter_server_terminals     0.4.4
    jupyterlab                   4.0.2
    jupyterlab-pygments          0.2.2
    jupyterlab_server            2.23.0
    jupyterlab-widgets           3.0.8
    keras                        2.13.1
    kiwisolver                   1.4.4
    libclang                     16.0.6
    Markdown                     3.4.3
    MarkupSafe                   2.1.1
    matplotlib                   3.7.2
    matplotlib-inline            0.1.6
    mistune                      3.0.1
    mysql                        0.0.3
    mysql-connector              2.2.9
    mysql-connector-python       8.0.33
    mysqlclient                  2.1.1
    nbclassic                    1.0.0
    nbclient                     0.8.0
    nbconvert                    7.6.0
    nbformat                     5.9.0
    nest-asyncio                 1.5.6
    notebook                     6.5.4
    notebook_shim                0.2.3
    numpy                        1.24.3
    oauthlib                     3.2.2
    opencv-python                4.8.0.74
    opt-einsum                   3.3.0
    overrides                    7.3.1
    packaging                    23.1
    pandas                       2.0.2
    pandocfilters                1.5.0
    parso                        0.8.3
    pickleshare                  0.7.5
    Pillow                       10.0.0
    pip                          23.2
    platformdirs                 3.5.0
    prometheus-client            0.17.0
    prompt-toolkit               3.0.38
    protobuf                     3.20.3
    psutil                       5.9.5
    pure-eval                    0.2.2
    pyasn1                       0.5.0
    pyasn1-modules               0.3.0
    pycparser                    2.21
    pygame                       2.4.0
    Pygments                     2.15.1
    pyparsing                    3.0.9
    pyrsistent                   0.19.3
    python-dateutil              2.8.2
    python-json-logger           2.0.7
    pytz                         2023.3
    pywin32                      306
    pywinpty                     2.0.10
    PyYAML                       6.0
    pyzmq                        25.0.2
    qtconsole                    5.4.3
    QtPy                         2.3.1
    requests                     2.31.0
    requests-oauthlib            1.3.1
    rfc3339-validator            0.1.4
    rfc3986-validator            0.1.1
    rsa                          4.9
    Send2Trash                   1.8.2
    setuptools                   63.2.0
    six                          1.16.0
    sniffio                      1.3.0
    soupsieve                    2.4
    stack-data                   0.6.2
    tabulate                     0.9.0
    tensorboard                  2.13.0
    tensorboard-data-server      0.7.1
    tensorflow-estimator         2.13.0
    tensorflow-intel             2.13.0
    tensorflow-io-gcs-filesystem 0.31.0
    termcolor                    2.3.0
    terminado                    0.17.1
    tinycss2                     1.2.1
    tomli                        2.0.1
    tornado                      6.3.1
    traitlets                    5.9.0
    typing                       3.7.4.3
    typing_extensions            4.5.0
    tzdata                       2023.3
    uri-template                 1.3.0
    urllib3                      1.26.16
    wcwidth                      0.2.6
    webcolors                    1.13
    webencodings                 0.5.1
    websocket-client             1.6.1
    Werkzeug                     2.2.2
    wget                         3.2
    wheel                        0.40.0
    widgetsnbextension           4.0.8
    wrapt                        1.15.0
    


```python
import tensorflow as tf
import os
```


```python
# to see all gpu available in the system
gpus = tf.config.experimental.list_physical_devices('GPU')
print(gpus)
print(len(gpus))     # to get number of gpu available
```

    [PhysicalDevice(name='/physical_device:GPU:0', device_type='GPU')]
    1
    


```python
# to see all cpu available in the system
gpus = tf.config.experimental.list_physical_devices('CPU')
print(gpus)
print(len(gpus))     # to get number of cpu available
```

    [PhysicalDevice(name='/physical_device:CPU:0', device_type='CPU')]
    1
    


```python
import cv2
import imghdr
```


```python
data_dir = 'train'   #gives path to directory
```


```python
os.listdir('train')   #list folders inside
```




    ['nr', 'r']




```python
# to see number of files harzardous folder
print(len(os.listdir(os.path.join('train','r'))))
```

    9999
    


```python
# to see number of files recyclable folder
print(len(os.listdir(os.path.join('train','nr'))))
```

    12565
    


```python
# immage extensions that work
image_exts = ['jpeg','jpg','bmp','png']
```


```python
from matplotlib import pyplot as plt
```


```python
# reding an image using cv2
img = cv2.imread(os.path.join('train','r', 'R_1.jpg'))
print(img)
# reads images numpy array
```

    [[[233 235 235]
      [233 235 235]
      [233 235 235]
      ...
      [230 235 234]
      [230 235 234]
      [230 235 234]]
    
     [[233 235 235]
      [233 235 235]
      [233 235 235]
      ...
      [230 235 234]
      [230 235 234]
      [230 235 234]]
    
     [[233 235 235]
      [233 235 235]
      [233 235 235]
      ...
      [230 235 234]
      [230 235 234]
      [230 235 234]]
    
     ...
    
     [[141 172 223]
      [141 172 223]
      [140 171 222]
      ...
      [134 160 206]
      [139 165 211]
      [140 166 212]]
    
     [[140 171 222]
      [140 171 222]
      [139 170 221]
      ...
      [132 158 204]
      [138 164 210]
      [138 164 210]]
    
     [[140 171 222]
      [139 170 221]
      [138 169 220]
      ...
      [131 157 203]
      [137 163 209]
      [137 163 209]]]
    


```python
plt.imshow(img)
# image would be bluish as opencv reads image as bgr not rgb
```




    <matplotlib.image.AxesImage at 0x1ed90def370>




    
![png](output_20_1.png)
    



```python
# to color it
plt.imshow(cv2.cvtColor(img,cv2.COLOR_BGR2RGB))
```




    <matplotlib.image.AxesImage at 0x1ed9400bf70>




    
![png](output_21_1.png)
    


# 2. Performing Cleanup of bad images


```python
# looping through each image to remove bad images
for image_class in os.listdir(data_dir):
    for image in os.listdir(os.path.join(data_dir,image_class)):
        image_path = os.path.join(data_dir, image_class, image)
        try:
            img = cv2.imread(image_path)
            tip = imghdr.what(image_path)
            if tip not in image_exts:
                print('Image does not exist in extension list {}'.format(image_path))
                os.remove(image_path)
        except Exception as e:
            print("Exception occured, ",e)
            print('Issue with image {}'.format(image_path))
```


```python
# after cleanup number of images left
# to see number of files harzardous folder
print(len(os.listdir(os.path.join('train','r'))))
```

    9999
    


```python
# to see number of files recyclable folder
print(len(os.listdir(os.path.join('train','nr'))))
```

    12565
    

# 3. Building a Data pipeline
Processing data in 2 classes namely 'Recyclable' , 'Non-Recyclable'


```python
import numpy as np
from matplotlib import pyplot as plt
```


```python
# data has 2 classes or is classified into 2 distinct classes
```


```python
# builds a data pipeline
data = tf.keras.utils.image_dataset_from_directory('train')
```

    Found 22564 files belonging to 2 classes.
    


```python
# allows us to access the pipeline
data_iterator = data.as_numpy_iterator()
```


```python
# accessing the pipeline
# creates a group  or collection of images
batch = data_iterator.next()
```


```python
# a batch(group of data)
# a set of images made to perform process effeciently
batch
```




    (array([[[[8.80000000e+01, 9.30000000e+01, 9.60000000e+01],
              [8.80000000e+01, 9.30000000e+01, 9.60000000e+01],
              [8.80000000e+01, 9.30000000e+01, 9.60000000e+01],
              ...,
              [1.63371094e+02, 1.59371094e+02, 1.60371094e+02],
              [1.63000000e+02, 1.59000000e+02, 1.60000000e+02],
              [1.63000000e+02, 1.59000000e+02, 1.60000000e+02]],
     
             [[8.85722656e+01, 9.35722656e+01, 9.65722656e+01],
              [8.85085602e+01, 9.35085602e+01, 9.65085602e+01],
              [8.80000000e+01, 9.30000000e+01, 9.60000000e+01],
              ...,
              [1.62120377e+02, 1.58120377e+02, 1.59120377e+02],
              [1.61855469e+02, 1.57855469e+02, 1.58855469e+02],
              [1.61855469e+02, 1.57855469e+02, 1.58855469e+02]],
     
             [[8.90000000e+01, 9.40000000e+01, 9.70000000e+01],
              [8.89206390e+01, 9.39206390e+01, 9.69206390e+01],
              [8.82871094e+01, 9.32871094e+01, 9.62871094e+01],
              ...,
              [1.60270950e+02, 1.56270950e+02, 1.57270950e+02],
              [1.60138672e+02, 1.56138672e+02, 1.57138672e+02],
              [1.60138672e+02, 1.56138672e+02, 1.57138672e+02]],
     
             ...,
     
             [[5.05076981e+00, 8.87924576e+00, 1.08792458e+01],
              [2.70969772e+00, 9.44264603e+00, 1.14426460e+01],
              [7.13032150e+00, 1.43366737e+01, 1.63366737e+01],
              ...,
              [4.37965088e+01, 3.17819595e+01, 2.42215538e+01],
              [3.92707710e+01, 2.92285156e+01, 2.73265457e+01],
              [3.86700974e+01, 2.85420799e+01, 2.71162987e+01]],
     
             [[4.76188660e-02, 3.05152512e+00, 5.47925949e+00],
              [1.95117188e+00, 8.93405914e+00, 1.13617935e+01],
              [5.93182755e+00, 1.32153702e+01, 1.56431046e+01],
              ...,
              [5.68025818e+01, 4.16143684e+01, 3.20506287e+01],
              [5.51215591e+01, 4.21879654e+01, 3.83796501e+01],
              [5.56786957e+01, 4.29677582e+01, 3.96845551e+01]],
     
             [[1.11328125e-01, 4.25976562e+00, 7.25976562e+00],
              [3.66796875e+00, 1.16679688e+01, 1.46679688e+01],
              [7.33007812e+00, 1.51445312e+01, 1.81445312e+01],
              ...,
              [5.88144531e+01, 4.14433594e+01, 3.17734375e+01],
              [5.90000000e+01, 4.37773438e+01, 3.84433594e+01],
              [6.18886719e+01, 4.68886719e+01, 4.18886719e+01]]],
     
     
            [[[2.55000000e+02, 2.55000000e+02, 2.55000000e+02],
              [2.55000000e+02, 2.55000000e+02, 2.55000000e+02],
              [2.55000000e+02, 2.55000000e+02, 2.55000000e+02],
              ...,
              [2.55000000e+02, 2.55000000e+02, 2.55000000e+02],
              [2.55000000e+02, 2.55000000e+02, 2.55000000e+02],
              [2.55000000e+02, 2.55000000e+02, 2.55000000e+02]],
     
             [[2.55000000e+02, 2.55000000e+02, 2.55000000e+02],
              [2.55000000e+02, 2.55000000e+02, 2.55000000e+02],
              [2.55000000e+02, 2.55000000e+02, 2.55000000e+02],
              ...,
              [2.55000000e+02, 2.55000000e+02, 2.55000000e+02],
              [2.55000000e+02, 2.55000000e+02, 2.55000000e+02],
              [2.55000000e+02, 2.55000000e+02, 2.55000000e+02]],
     
             [[2.55000000e+02, 2.55000000e+02, 2.55000000e+02],
              [2.55000000e+02, 2.55000000e+02, 2.55000000e+02],
              [2.55000000e+02, 2.55000000e+02, 2.55000000e+02],
              ...,
              [2.55000000e+02, 2.55000000e+02, 2.55000000e+02],
              [2.55000000e+02, 2.55000000e+02, 2.55000000e+02],
              [2.55000000e+02, 2.55000000e+02, 2.55000000e+02]],
     
             ...,
     
             [[2.55000000e+02, 2.55000000e+02, 2.55000000e+02],
              [2.55000000e+02, 2.55000000e+02, 2.55000000e+02],
              [2.55000000e+02, 2.55000000e+02, 2.55000000e+02],
              ...,
              [2.55000000e+02, 2.55000000e+02, 2.55000000e+02],
              [2.55000000e+02, 2.55000000e+02, 2.55000000e+02],
              [2.55000000e+02, 2.55000000e+02, 2.55000000e+02]],
     
             [[2.55000000e+02, 2.55000000e+02, 2.55000000e+02],
              [2.55000000e+02, 2.55000000e+02, 2.55000000e+02],
              [2.55000000e+02, 2.55000000e+02, 2.55000000e+02],
              ...,
              [2.55000000e+02, 2.55000000e+02, 2.55000000e+02],
              [2.55000000e+02, 2.55000000e+02, 2.55000000e+02],
              [2.55000000e+02, 2.55000000e+02, 2.55000000e+02]],
     
             [[2.55000000e+02, 2.55000000e+02, 2.55000000e+02],
              [2.55000000e+02, 2.55000000e+02, 2.55000000e+02],
              [2.55000000e+02, 2.55000000e+02, 2.55000000e+02],
              ...,
              [2.55000000e+02, 2.55000000e+02, 2.55000000e+02],
              [2.55000000e+02, 2.55000000e+02, 2.55000000e+02],
              [2.55000000e+02, 2.55000000e+02, 2.55000000e+02]]],
     
     
            [[[1.67000000e+02, 6.90000000e+01, 2.20000000e+01],
              [1.67000000e+02, 7.69531250e+01, 4.28769531e+01],
              [1.62048828e+02, 8.09609375e+01, 5.98339844e+01],
              ...,
              [2.55000000e+02, 2.50980469e+02, 2.50970703e+02],
              [2.55000000e+02, 2.48976562e+02, 2.47947266e+02],
              [2.55000000e+02, 2.45000000e+02, 2.39000000e+02]],
     
             [[1.54617188e+02, 7.82871094e+01, 4.11933594e+01],
              [1.34305267e+02, 6.10042076e+01, 2.88326187e+01],
              [1.59889099e+02, 8.87739563e+01, 6.21472969e+01],
              ...,
              [2.47527985e+02, 2.46700897e+02, 2.47905228e+02],
              [2.43294373e+02, 2.50243866e+02, 2.48005310e+02],
              [2.53142578e+02, 2.51191406e+02, 2.48906250e+02]],
     
             [[1.44443359e+02, 8.29042969e+01, 6.39570312e+01],
              [1.31243805e+02, 6.89785614e+01, 4.16801262e+01],
              [1.57281509e+02, 9.08615112e+01, 5.69090652e+01],
              ...,
              [2.47339417e+02, 2.46600037e+02, 2.48214508e+02],
              [2.42975418e+02, 2.51023438e+02, 2.50582672e+02],
              [2.49078125e+02, 2.55000000e+02, 2.55000000e+02]],
     
             ...,
     
             [[2.55000000e+02, 2.55000000e+02, 2.55000000e+02],
              [2.55000000e+02, 2.55000000e+02, 2.55000000e+02],
              [2.55000000e+02, 2.55000000e+02, 2.55000000e+02],
              ...,
              [1.91952194e+02, 1.05289749e+02, 5.74570351e+01],
              [1.85241714e+02, 8.60620270e+01, 5.88735046e+01],
              [1.71574219e+02, 7.14003906e+01, 6.39218750e+01]],
     
             [[2.55000000e+02, 2.55000000e+02, 2.55000000e+02],
              [2.55000000e+02, 2.55000000e+02, 2.55000000e+02],
              [2.55000000e+02, 2.55000000e+02, 2.55000000e+02],
              ...,
              [1.88266449e+02, 1.03190094e+02, 6.98228302e+01],
              [1.76646759e+02, 7.90753250e+01, 6.18155670e+01],
              [1.73378906e+02, 7.59492188e+01, 7.12832031e+01]],
     
             [[2.55000000e+02, 2.55000000e+02, 2.55000000e+02],
              [2.55000000e+02, 2.55000000e+02, 2.55000000e+02],
              [2.55000000e+02, 2.55000000e+02, 2.55000000e+02],
              ...,
              [1.88921875e+02, 1.08804688e+02, 8.59023438e+01],
              [1.81035156e+02, 8.90468750e+01, 7.60703125e+01],
              [1.87000000e+02, 9.70000000e+01, 8.80000000e+01]]],
     
     
            ...,
     
     
            [[[6.00000000e+00, 5.00000000e+00, 1.00000000e+01],
              [6.00000000e+00, 5.00000000e+00, 1.00000000e+01],
              [6.00000000e+00, 5.00000000e+00, 1.00000000e+01],
              ...,
              [5.46972656e+01, 5.16972656e+01, 5.86972656e+01],
              [5.36367188e+01, 5.10000000e+01, 5.78183594e+01],
              [5.20000000e+01, 5.10000000e+01, 5.70000000e+01]],
     
             [[6.00000000e+00, 5.00000000e+00, 1.00000000e+01],
              [6.00000000e+00, 5.00000000e+00, 1.00000000e+01],
              [6.00000000e+00, 5.00000000e+00, 1.00000000e+01],
              ...,
              [5.24899330e+01, 4.94899330e+01, 5.64899330e+01],
              [5.20000000e+01, 4.93632812e+01, 5.61816406e+01],
              [5.03632812e+01, 4.93632812e+01, 5.53632812e+01]],
     
             [[6.00000000e+00, 5.00000000e+00, 1.00000000e+01],
              [6.00000000e+00, 5.00000000e+00, 1.00000000e+01],
              [6.00000000e+00, 5.00000000e+00, 1.00000000e+01],
              ...,
              [4.92109375e+01, 4.62109375e+01, 5.32109375e+01],
              [4.87210045e+01, 4.60842857e+01, 5.29026451e+01],
              [4.65136719e+01, 4.55136719e+01, 5.15136719e+01]],
     
             ...,
     
             [[8.75332031e+01, 7.72304688e+01, 7.40195312e+01],
              [1.05965469e+02, 9.59104767e+01, 9.19563065e+01],
              [8.94518967e+01, 7.93048172e+01, 7.39382248e+01],
              ...,
              [3.50758362e+01, 2.50756874e+01, 2.28368111e+01],
              [4.56615067e+01, 3.52725334e+01, 3.27534485e+01],
              [5.33496094e+01, 4.02578125e+01, 3.89550781e+01]],
     
             [[5.04492188e+01, 3.90859375e+01, 3.12695312e+01],
              [5.39448280e+01, 4.32512589e+01, 3.34257164e+01],
              [4.50202675e+01, 3.23835487e+01, 2.28093300e+01],
              ...,
              [1.13188171e+01, 4.49143982e+00, 3.95012283e+00],
              [1.09960938e+01, 3.73179245e+00, 4.09507370e+00],
              [1.75429688e+01, 7.45117188e+00, 6.17773438e+00]],
     
             [[7.50000000e+01, 6.20000000e+01, 4.60000000e+01],
              [8.31835938e+01, 7.01835938e+01, 5.41835938e+01],
              [8.50000000e+01, 6.99082031e+01, 5.46054688e+01],
              ...,
              [1.82109375e+01, 1.53027344e+01, 1.86054688e+01],
              [2.24531250e+01, 1.72714844e+01, 2.09082031e+01],
              [2.90000000e+01, 2.30000000e+01, 2.50000000e+01]]],
     
     
            [[[1.86375000e+02, 1.86375000e+02, 1.74375000e+02],
              [2.08476562e+02, 2.08476562e+02, 1.96992188e+02],
              [2.36015625e+02, 2.36015625e+02, 2.26015625e+02],
              ...,
              [1.62960938e+02, 1.03960938e+02, 9.76796875e+01],
              [1.53507812e+02, 9.52500000e+01, 8.42812500e+01],
              [1.78820312e+02, 1.20820312e+02, 1.06992188e+02]],
     
             [[1.98382202e+02, 1.98382202e+02, 1.87350952e+02],
              [2.00911987e+02, 2.00911987e+02, 1.90146606e+02],
              [2.33521851e+02, 2.33521851e+02, 2.23938110e+02],
              ...,
              [1.57216553e+02, 9.82165527e+01, 9.19353027e+01],
              [1.67233032e+02, 1.08975220e+02, 9.80064697e+01],
              [1.87209839e+02, 1.29209839e+02, 1.15381714e+02]],
     
             [[2.12922974e+02, 2.13063599e+02, 2.03344849e+02],
              [1.91579468e+02, 1.91683838e+02, 1.81965088e+02],
              [2.31207764e+02, 2.31147339e+02, 2.22348389e+02],
              ...,
              [1.49517334e+02, 9.05173340e+01, 8.42360840e+01],
              [1.82094238e+02, 1.23836426e+02, 1.12972046e+02],
              [1.95478149e+02, 1.37478149e+02, 1.23919189e+02]],
     
             ...,
     
             [[1.78185547e+02, 1.42185547e+02, 1.18185547e+02],
              [1.82143188e+02, 1.46143188e+02, 1.22143188e+02],
              [1.81170898e+02, 1.45170898e+02, 1.21170898e+02],
              ...,
              [1.88333862e+02, 1.66333862e+02, 1.43333862e+02],
              [1.91684692e+02, 1.69684692e+02, 1.46684692e+02],
              [1.95821045e+02, 1.73821045e+02, 1.50821045e+02]],
     
             [[1.78552124e+02, 1.42552124e+02, 1.18552124e+02],
              [1.80718994e+02, 1.44718994e+02, 1.20718994e+02],
              [1.77785645e+02, 1.41785645e+02, 1.17785645e+02],
              ...,
              [1.84617188e+02, 1.62617188e+02, 1.39617188e+02],
              [1.88898193e+02, 1.66898193e+02, 1.43898193e+02],
              [1.93122437e+02, 1.71122437e+02, 1.48122437e+02]],
     
             [[1.76171875e+02, 1.40171875e+02, 1.16171875e+02],
              [1.79031250e+02, 1.43031250e+02, 1.19031250e+02],
              [1.75984375e+02, 1.39984375e+02, 1.15984375e+02],
              ...,
              [1.81710938e+02, 1.59710938e+02, 1.36710938e+02],
              [1.86710938e+02, 1.64710938e+02, 1.41710938e+02],
              [1.90742188e+02, 1.68742188e+02, 1.45742188e+02]]],
     
     
            [[[0.00000000e+00, 0.00000000e+00, 0.00000000e+00],
              [0.00000000e+00, 0.00000000e+00, 0.00000000e+00],
              [0.00000000e+00, 0.00000000e+00, 0.00000000e+00],
              ...,
              [0.00000000e+00, 0.00000000e+00, 0.00000000e+00],
              [0.00000000e+00, 0.00000000e+00, 0.00000000e+00],
              [0.00000000e+00, 0.00000000e+00, 0.00000000e+00]],
     
             [[0.00000000e+00, 0.00000000e+00, 0.00000000e+00],
              [0.00000000e+00, 0.00000000e+00, 0.00000000e+00],
              [0.00000000e+00, 0.00000000e+00, 0.00000000e+00],
              ...,
              [0.00000000e+00, 0.00000000e+00, 0.00000000e+00],
              [0.00000000e+00, 0.00000000e+00, 0.00000000e+00],
              [0.00000000e+00, 0.00000000e+00, 0.00000000e+00]],
     
             [[0.00000000e+00, 0.00000000e+00, 0.00000000e+00],
              [0.00000000e+00, 0.00000000e+00, 0.00000000e+00],
              [0.00000000e+00, 0.00000000e+00, 0.00000000e+00],
              ...,
              [0.00000000e+00, 0.00000000e+00, 0.00000000e+00],
              [0.00000000e+00, 0.00000000e+00, 0.00000000e+00],
              [0.00000000e+00, 0.00000000e+00, 0.00000000e+00]],
     
             ...,
     
             [[0.00000000e+00, 0.00000000e+00, 0.00000000e+00],
              [0.00000000e+00, 0.00000000e+00, 0.00000000e+00],
              [0.00000000e+00, 0.00000000e+00, 0.00000000e+00],
              ...,
              [0.00000000e+00, 0.00000000e+00, 0.00000000e+00],
              [0.00000000e+00, 0.00000000e+00, 0.00000000e+00],
              [0.00000000e+00, 0.00000000e+00, 0.00000000e+00]],
     
             [[0.00000000e+00, 0.00000000e+00, 0.00000000e+00],
              [0.00000000e+00, 0.00000000e+00, 0.00000000e+00],
              [0.00000000e+00, 0.00000000e+00, 0.00000000e+00],
              ...,
              [0.00000000e+00, 0.00000000e+00, 0.00000000e+00],
              [0.00000000e+00, 0.00000000e+00, 0.00000000e+00],
              [0.00000000e+00, 0.00000000e+00, 0.00000000e+00]],
     
             [[0.00000000e+00, 0.00000000e+00, 0.00000000e+00],
              [0.00000000e+00, 0.00000000e+00, 0.00000000e+00],
              [0.00000000e+00, 0.00000000e+00, 0.00000000e+00],
              ...,
              [0.00000000e+00, 0.00000000e+00, 0.00000000e+00],
              [0.00000000e+00, 0.00000000e+00, 0.00000000e+00],
              [0.00000000e+00, 0.00000000e+00, 0.00000000e+00]]]],
           dtype=float32),
     array([0, 0, 0, 0, 1, 1, 0, 0, 1, 1, 1, 0, 1, 1, 0, 0, 0, 1, 0, 1, 0, 1,
            0, 0, 1, 1, 0, 1, 0, 0, 0, 0]))




```python
fig, ax = plt.subplots(ncols=4, figsize=(20,20))
for idx, img in enumerate(batch[0][:4]):
    ax[idx].imshow(img.astype(int))
    ax[idx].title.set_text(batch[1][idx])
```


    
![png](output_33_0.png)
    



```python
# the above result shows
# 0 - Non - Recyclable
# 1 - Recyclable
```

# 3. Preprocessing Data
Cleaning, transforming, and preparing raw data to make it suitable to be used as input for deep learning model


```python
scaled = batch[0] / 255
```


```python
scaled
```




    array([[[[3.45098048e-01, 3.64705890e-01, 3.76470596e-01],
             [3.45098048e-01, 3.64705890e-01, 3.76470596e-01],
             [3.45098048e-01, 3.64705890e-01, 3.76470596e-01],
             ...,
             [6.40670955e-01, 6.24984682e-01, 6.28906250e-01],
             [6.39215708e-01, 6.23529434e-01, 6.27451003e-01],
             [6.39215708e-01, 6.23529434e-01, 6.27451003e-01]],
    
            [[3.47342223e-01, 3.66950065e-01, 3.78714770e-01],
             [3.47092390e-01, 3.66700232e-01, 3.78464937e-01],
             [3.45098048e-01, 3.64705890e-01, 3.76470596e-01],
             ...,
             [6.35766208e-01, 6.20079935e-01, 6.24001503e-01],
             [6.34727299e-01, 6.19041026e-01, 6.22962594e-01],
             [6.34727299e-01, 6.19041026e-01, 6.22962594e-01]],
    
            [[3.49019617e-01, 3.68627459e-01, 3.80392164e-01],
             [3.48708391e-01, 3.68316233e-01, 3.80080938e-01],
             [3.46223950e-01, 3.65831792e-01, 3.77596498e-01],
             ...,
             [6.28513515e-01, 6.12827241e-01, 6.16748810e-01],
             [6.27994776e-01, 6.12308502e-01, 6.16230071e-01],
             [6.27994776e-01, 6.12308502e-01, 6.16230071e-01]],
    
            ...,
    
            [[1.98069401e-02, 3.48205715e-02, 4.26637083e-02],
             [1.06262658e-02, 3.70299853e-02, 4.48731221e-02],
             [2.79620457e-02, 5.62222488e-02, 6.40653893e-02],
             ...,
             [1.71751007e-01, 1.24635138e-01, 9.49864835e-02],
             [1.54003024e-01, 1.14621632e-01, 1.07162923e-01],
             [1.51647434e-01, 1.11929722e-01, 1.06338426e-01]],
    
            [[1.86740654e-04, 1.19667649e-02, 2.14872919e-02],
             [7.65165454e-03, 3.50355245e-02, 4.45560515e-02],
             [2.32620686e-02, 5.18249795e-02, 6.13455065e-02],
             ...,
             [2.22755224e-01, 1.63193598e-01, 1.25688747e-01],
             [2.16162980e-01, 1.65443003e-01, 1.50508434e-01],
             [2.18347833e-01, 1.68501019e-01, 1.55625701e-01]],
    
            [[4.36580885e-04, 1.67049635e-02, 2.84696687e-02],
             [1.43841915e-02, 4.57567386e-02, 5.75214475e-02],
             [2.87454035e-02, 5.93903176e-02, 7.11550266e-02],
             ...,
             [2.30644912e-01, 1.62522972e-01, 1.24601714e-01],
             [2.31372550e-01, 1.71675861e-01, 1.50758266e-01],
             [2.42700681e-01, 1.83877140e-01, 1.64269298e-01]]],
    
    
           [[[1.00000000e+00, 1.00000000e+00, 1.00000000e+00],
             [1.00000000e+00, 1.00000000e+00, 1.00000000e+00],
             [1.00000000e+00, 1.00000000e+00, 1.00000000e+00],
             ...,
             [1.00000000e+00, 1.00000000e+00, 1.00000000e+00],
             [1.00000000e+00, 1.00000000e+00, 1.00000000e+00],
             [1.00000000e+00, 1.00000000e+00, 1.00000000e+00]],
    
            [[1.00000000e+00, 1.00000000e+00, 1.00000000e+00],
             [1.00000000e+00, 1.00000000e+00, 1.00000000e+00],
             [1.00000000e+00, 1.00000000e+00, 1.00000000e+00],
             ...,
             [1.00000000e+00, 1.00000000e+00, 1.00000000e+00],
             [1.00000000e+00, 1.00000000e+00, 1.00000000e+00],
             [1.00000000e+00, 1.00000000e+00, 1.00000000e+00]],
    
            [[1.00000000e+00, 1.00000000e+00, 1.00000000e+00],
             [1.00000000e+00, 1.00000000e+00, 1.00000000e+00],
             [1.00000000e+00, 1.00000000e+00, 1.00000000e+00],
             ...,
             [1.00000000e+00, 1.00000000e+00, 1.00000000e+00],
             [1.00000000e+00, 1.00000000e+00, 1.00000000e+00],
             [1.00000000e+00, 1.00000000e+00, 1.00000000e+00]],
    
            ...,
    
            [[1.00000000e+00, 1.00000000e+00, 1.00000000e+00],
             [1.00000000e+00, 1.00000000e+00, 1.00000000e+00],
             [1.00000000e+00, 1.00000000e+00, 1.00000000e+00],
             ...,
             [1.00000000e+00, 1.00000000e+00, 1.00000000e+00],
             [1.00000000e+00, 1.00000000e+00, 1.00000000e+00],
             [1.00000000e+00, 1.00000000e+00, 1.00000000e+00]],
    
            [[1.00000000e+00, 1.00000000e+00, 1.00000000e+00],
             [1.00000000e+00, 1.00000000e+00, 1.00000000e+00],
             [1.00000000e+00, 1.00000000e+00, 1.00000000e+00],
             ...,
             [1.00000000e+00, 1.00000000e+00, 1.00000000e+00],
             [1.00000000e+00, 1.00000000e+00, 1.00000000e+00],
             [1.00000000e+00, 1.00000000e+00, 1.00000000e+00]],
    
            [[1.00000000e+00, 1.00000000e+00, 1.00000000e+00],
             [1.00000000e+00, 1.00000000e+00, 1.00000000e+00],
             [1.00000000e+00, 1.00000000e+00, 1.00000000e+00],
             ...,
             [1.00000000e+00, 1.00000000e+00, 1.00000000e+00],
             [1.00000000e+00, 1.00000000e+00, 1.00000000e+00],
             [1.00000000e+00, 1.00000000e+00, 1.00000000e+00]]],
    
    
           [[[6.54901981e-01, 2.70588249e-01, 8.62745121e-02],
             [6.54901981e-01, 3.01776975e-01, 1.68144912e-01],
             [6.35485590e-01, 3.17493886e-01, 2.34643072e-01],
             ...,
             [1.00000000e+00, 9.84237134e-01, 9.84198809e-01],
             [1.00000000e+00, 9.76378679e-01, 9.72342193e-01],
             [1.00000000e+00, 9.60784316e-01, 9.37254906e-01]],
    
            [[6.06341898e-01, 3.07008266e-01, 1.61542580e-01],
             [5.26687324e-01, 2.39232183e-01, 1.13069095e-01],
             [6.27016068e-01, 3.48133177e-01, 2.43714884e-01],
             ...,
             [9.70697999e-01, 9.67454493e-01, 9.72177386e-01],
             [9.54095602e-01, 9.81348515e-01, 9.72569823e-01],
             [9.92716014e-01, 9.85064328e-01, 9.76102948e-01]],
    
            [[5.66444576e-01, 3.25114876e-01, 2.50811875e-01],
             [5.14681578e-01, 2.70504177e-01, 1.63451478e-01],
             [6.16790235e-01, 3.56319666e-01, 2.23172799e-01],
             ...,
             [9.69958484e-01, 9.67058957e-01, 9.73390222e-01],
             [9.52844799e-01, 9.84405637e-01, 9.82677162e-01],
             [9.76776958e-01, 1.00000000e+00, 1.00000000e+00]],
    
            ...,
    
            [[1.00000000e+00, 1.00000000e+00, 1.00000000e+00],
             [1.00000000e+00, 1.00000000e+00, 1.00000000e+00],
             [1.00000000e+00, 1.00000000e+00, 1.00000000e+00],
             ...,
             [7.52753675e-01, 4.12900984e-01, 2.25321710e-01],
             [7.26438105e-01, 3.37498158e-01, 2.30876490e-01],
             [6.72840059e-01, 2.80001521e-01, 2.50674009e-01]],
    
            [[1.00000000e+00, 1.00000000e+00, 1.00000000e+00],
             [1.00000000e+00, 1.00000000e+00, 1.00000000e+00],
             [1.00000000e+00, 1.00000000e+00, 1.00000000e+00],
             ...,
             [7.38299787e-01, 4.04667050e-01, 2.73815006e-01],
             [6.92732394e-01, 3.10099304e-01, 2.42413983e-01],
             [6.79917276e-01, 2.97840059e-01, 2.79541969e-01]],
    
            [[1.00000000e+00, 1.00000000e+00, 1.00000000e+00],
             [1.00000000e+00, 1.00000000e+00, 1.00000000e+00],
             [1.00000000e+00, 1.00000000e+00, 1.00000000e+00],
             ...,
             [7.40870118e-01, 4.26685035e-01, 3.36871922e-01],
             [7.09941804e-01, 3.49203438e-01, 2.98314959e-01],
             [7.33333349e-01, 3.80392164e-01, 3.45098048e-01]]],
    
    
           ...,
    
    
           [[[2.35294122e-02, 1.96078438e-02, 3.92156877e-02],
             [2.35294122e-02, 1.96078438e-02, 3.92156877e-02],
             [2.35294122e-02, 1.96078438e-02, 3.92156877e-02],
             ...,
             [2.14499086e-01, 2.02734381e-01, 2.30185360e-01],
             [2.10340068e-01, 2.00000003e-01, 2.26738662e-01],
             [2.03921571e-01, 2.00000003e-01, 2.23529413e-01]],
    
            [[2.35294122e-02, 1.96078438e-02, 3.92156877e-02],
             [2.35294122e-02, 1.96078438e-02, 3.92156877e-02],
             [2.35294122e-02, 1.96078438e-02, 3.92156877e-02],
             ...,
             [2.05842867e-01, 1.94078162e-01, 2.21529156e-01],
             [2.03921571e-01, 1.93581492e-01, 2.20320165e-01],
             [1.97503060e-01, 1.93581492e-01, 2.17110902e-01]],
    
            [[2.35294122e-02, 1.96078438e-02, 3.92156877e-02],
             [2.35294122e-02, 1.96078438e-02, 3.92156877e-02],
             [2.35294122e-02, 1.96078438e-02, 3.92156877e-02],
             ...,
             [1.92984074e-01, 1.81219369e-01, 2.08670348e-01],
             [1.91062763e-01, 1.80722684e-01, 2.07461357e-01],
             [1.82406560e-01, 1.78484991e-01, 2.02014402e-01]],
    
            ...,
    
            [[3.43267471e-01, 3.02864581e-01, 2.90272683e-01],
             [4.15550858e-01, 3.76119524e-01, 3.60612959e-01],
             [3.50791752e-01, 3.10999274e-01, 2.89953828e-01],
             ...,
             [1.37552306e-01, 9.83360261e-02, 8.95561203e-02],
             [1.79064736e-01, 1.38323665e-01, 1.28444895e-01],
             [2.09214151e-01, 1.57873780e-01, 1.52765006e-01]],
    
            [[1.97840080e-01, 1.53278187e-01, 1.22625612e-01],
             [2.11548343e-01, 1.69612780e-01, 1.31081238e-01],
             [1.76550075e-01, 1.26994312e-01, 8.94483551e-02],
             ...,
             [4.43875194e-02, 1.76134892e-02, 1.54906781e-02],
             [4.31219377e-02, 1.46344798e-02, 1.60591118e-02],
             [6.87959567e-02, 2.92202812e-02, 2.42264085e-02]],
    
            [[2.94117659e-01, 2.43137255e-01, 1.80392161e-01],
             [3.26210171e-01, 2.75229782e-01, 2.12484688e-01],
             [3.33333343e-01, 2.74149805e-01, 2.14139089e-01],
             ...,
             [7.14154392e-02, 6.00107238e-02, 7.29626194e-02],
             [8.80514681e-02, 6.77313134e-02, 8.19929540e-02],
             [1.13725491e-01, 9.01960805e-02, 9.80392173e-02]]],
    
    
           [[[7.30882347e-01, 7.30882347e-01, 6.83823526e-01],
             [8.17555130e-01, 8.17555130e-01, 7.72518396e-01],
             [9.25551474e-01, 9.25551474e-01, 8.86335790e-01],
             ...,
             [6.39062524e-01, 4.07689959e-01, 3.83057594e-01],
             [6.01991415e-01, 3.73529404e-01, 3.30514699e-01],
             [7.01256156e-01, 4.73805159e-01, 4.19577211e-01]],
    
            [[7.77969420e-01, 7.77969420e-01, 7.34709620e-01],
             [7.87890136e-01, 7.87890136e-01, 7.45672941e-01],
             [9.15771961e-01, 9.15771961e-01, 8.78188670e-01],
             ...,
             [6.16535485e-01, 3.85162950e-01, 3.60530585e-01],
             [6.55815840e-01, 4.27353799e-01, 3.84339094e-01],
             [7.34156251e-01, 5.06705225e-01, 4.52477306e-01]],
    
            [[8.34992051e-01, 8.35543513e-01, 7.97430754e-01],
             [7.51292050e-01, 7.51701295e-01, 7.13588595e-01],
             [9.06697094e-01, 9.06460166e-01, 8.71954441e-01],
             ...,
             [5.86342514e-01, 3.54969949e-01, 3.30337584e-01],
             [7.14095056e-01, 4.85633045e-01, 4.43027645e-01],
             [7.66580999e-01, 5.39129972e-01, 4.85957593e-01]],
    
            ...,
    
            [[6.98766828e-01, 5.57590365e-01, 4.63472724e-01],
             [7.14287043e-01, 5.73110521e-01, 4.78992909e-01],
             [7.10474133e-01, 5.69297612e-01, 4.75180000e-01],
             ...,
             [7.38564193e-01, 6.52289629e-01, 5.62093556e-01],
             [7.51704693e-01, 6.65430188e-01, 5.75234115e-01],
             [7.67925680e-01, 6.81651175e-01, 5.91455102e-01]],
    
            [[7.00204432e-01, 5.59027910e-01, 4.64910299e-01],
             [7.08701909e-01, 5.67525446e-01, 4.73407835e-01],
             [6.97198629e-01, 5.56022108e-01, 4.61904496e-01],
             ...,
             [7.23988950e-01, 6.37714446e-01, 5.47518373e-01],
             [7.40777254e-01, 6.54502690e-01, 5.64306617e-01],
             [7.57342875e-01, 6.71068370e-01, 5.80872297e-01]],
    
            [[6.90870106e-01, 5.49693644e-01, 4.55575973e-01],
             [7.02083349e-01, 5.60906887e-01, 4.66789216e-01],
             [6.90134823e-01, 5.48958361e-01, 4.54840690e-01],
             ...,
             [7.12591887e-01, 6.26317382e-01, 5.36121309e-01],
             [7.32199728e-01, 6.45925224e-01, 5.55729151e-01],
             [7.48008549e-01, 6.61734045e-01, 5.71537971e-01]]],
    
    
           [[[0.00000000e+00, 0.00000000e+00, 0.00000000e+00],
             [0.00000000e+00, 0.00000000e+00, 0.00000000e+00],
             [0.00000000e+00, 0.00000000e+00, 0.00000000e+00],
             ...,
             [0.00000000e+00, 0.00000000e+00, 0.00000000e+00],
             [0.00000000e+00, 0.00000000e+00, 0.00000000e+00],
             [0.00000000e+00, 0.00000000e+00, 0.00000000e+00]],
    
            [[0.00000000e+00, 0.00000000e+00, 0.00000000e+00],
             [0.00000000e+00, 0.00000000e+00, 0.00000000e+00],
             [0.00000000e+00, 0.00000000e+00, 0.00000000e+00],
             ...,
             [0.00000000e+00, 0.00000000e+00, 0.00000000e+00],
             [0.00000000e+00, 0.00000000e+00, 0.00000000e+00],
             [0.00000000e+00, 0.00000000e+00, 0.00000000e+00]],
    
            [[0.00000000e+00, 0.00000000e+00, 0.00000000e+00],
             [0.00000000e+00, 0.00000000e+00, 0.00000000e+00],
             [0.00000000e+00, 0.00000000e+00, 0.00000000e+00],
             ...,
             [0.00000000e+00, 0.00000000e+00, 0.00000000e+00],
             [0.00000000e+00, 0.00000000e+00, 0.00000000e+00],
             [0.00000000e+00, 0.00000000e+00, 0.00000000e+00]],
    
            ...,
    
            [[0.00000000e+00, 0.00000000e+00, 0.00000000e+00],
             [0.00000000e+00, 0.00000000e+00, 0.00000000e+00],
             [0.00000000e+00, 0.00000000e+00, 0.00000000e+00],
             ...,
             [0.00000000e+00, 0.00000000e+00, 0.00000000e+00],
             [0.00000000e+00, 0.00000000e+00, 0.00000000e+00],
             [0.00000000e+00, 0.00000000e+00, 0.00000000e+00]],
    
            [[0.00000000e+00, 0.00000000e+00, 0.00000000e+00],
             [0.00000000e+00, 0.00000000e+00, 0.00000000e+00],
             [0.00000000e+00, 0.00000000e+00, 0.00000000e+00],
             ...,
             [0.00000000e+00, 0.00000000e+00, 0.00000000e+00],
             [0.00000000e+00, 0.00000000e+00, 0.00000000e+00],
             [0.00000000e+00, 0.00000000e+00, 0.00000000e+00]],
    
            [[0.00000000e+00, 0.00000000e+00, 0.00000000e+00],
             [0.00000000e+00, 0.00000000e+00, 0.00000000e+00],
             [0.00000000e+00, 0.00000000e+00, 0.00000000e+00],
             ...,
             [0.00000000e+00, 0.00000000e+00, 0.00000000e+00],
             [0.00000000e+00, 0.00000000e+00, 0.00000000e+00],
             [0.00000000e+00, 0.00000000e+00, 0.00000000e+00]]]],
          dtype=float32)




```python
scaled.min()
```




    0.0




```python
scaled.max()
```




    1.0




```python
# scaling data
data = data.map(lambda x,y: (x/255, y))
```


```python
scaled_iterator = data.as_numpy_iterator()
# does shuffling
```


```python
batch = scaled_iterator.next()
```


```python
batch[0].max()
```




    1.0




```python
batch[0].min()
```




    0.0




```python
fig, ax = plt.subplots(ncols=4, figsize=(20,20))
for idx, img in enumerate(batch[0][:4]):
    ax[idx].imshow(img)
    ax[idx].title.set_text(batch[1][idx])
```


    
![png](output_45_0.png)
    



```python
len(data)
```




    706




```python
train_size = int(len(data)*.7)   # training set
val_size = int(len(data)*.2) + 1  # validation set
test_size = int(len(data)*.1) + 1  # testing set
```


```python
train_size
```




    494




```python
val_size
```




    142




```python
test_size
```




    71




```python
train = data.take(train_size)
val = data.skip(train_size).take(val_size)
test = data.skip(train_size).take(test_size)
```

# 4. Building Deep Learning Model
Using neural networks with multiple layers to learn patterns and make predictions


```python
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Dense, Flatten, Dropout
```


```python
model = Sequential()
```


```python
# other way
# more readable and clean
# 16- filters
# 3x3 size filters
# 1 - stride

model.add(Conv2D(16, (3,3), 1, activation='relu', input_shape=(256,256,3)))
model.add(MaxPooling2D())

model.add(Conv2D(32, (3,3), 1, activation='relu'))
model.add(MaxPooling2D())

model.add(Conv2D(16, (3,3), 1, activation='relu'))
model.add(MaxPooling2D())

model.add(Flatten())

model.add(Dense(256, activation='relu'))
model.add(Dense(1, activation='sigmoid'))
```


```python
# adam - optimizer
# defining losses
# binary classification
model.compile('adam', loss=tf.losses.BinaryCrossentropy(), metrics=['accuracy'])
```


```python
model.summary()
```

    Model: "sequential"
    _________________________________________________________________
     Layer (type)                Output Shape              Param #   
    =================================================================
     conv2d (Conv2D)             (None, 254, 254, 16)      448       
                                                                     
     max_pooling2d (MaxPooling2D  (None, 127, 127, 16)     0         
     )                                                               
                                                                     
     conv2d_1 (Conv2D)           (None, 125, 125, 32)      4640      
                                                                     
     max_pooling2d_1 (MaxPooling  (None, 62, 62, 32)       0         
     2D)                                                             
                                                                     
     conv2d_2 (Conv2D)           (None, 60, 60, 16)        4624      
                                                                     
     max_pooling2d_2 (MaxPooling  (None, 30, 30, 16)       0         
     2D)                                                             
                                                                     
     flatten (Flatten)           (None, 14400)             0         
                                                                     
     dense (Dense)               (None, 256)               3686656   
                                                                     
     dense_1 (Dense)             (None, 1)                 257       
                                                                     
    =================================================================
    Total params: 3,696,625
    Trainable params: 3,696,625
    Non-trainable params: 0
    _________________________________________________________________
    

# 5. Training the Model
Iteratively optimizing model parameters using labeled data to minimize error and enable accurate predictions on new data


```python
logdir = 'logs'
```


```python
# callback important if we want to save the model at a particular checkpoint
# seeing the model
tensorboard_callback = tf.keras.callbacks.TensorBoard(log_dir=logdir)
```


```python
# 2 important methods of building a neural network
# model.fit - fit is a training component
# model.predict - it is used when we actually go and make predictions
# one epoch is how much time will we train for
# epoch is one run over our entire set of data

hist = model.fit(train, epochs=5, validation_data=val, callbacks=[tensorboard_callback])
```

    Epoch 1/5
    494/494 [==============================] - 254s 340ms/step - loss: 0.4654 - accuracy: 0.7910 - val_loss: 0.3996 - val_accuracy: 0.8213
    Epoch 2/5
    494/494 [==============================] - 165s 334ms/step - loss: 0.3754 - accuracy: 0.8417 - val_loss: 0.3505 - val_accuracy: 0.8523
    Epoch 3/5
    494/494 [==============================] - 166s 335ms/step - loss: 0.3153 - accuracy: 0.8684 - val_loss: 0.3639 - val_accuracy: 0.8556
    Epoch 4/5
    494/494 [==============================] - 165s 335ms/step - loss: 0.2531 - accuracy: 0.8979 - val_loss: 0.3872 - val_accuracy: 0.8488
    Epoch 5/5
    494/494 [==============================] - 165s 333ms/step - loss: 0.1966 - accuracy: 0.9242 - val_loss: 0.4327 - val_accuracy: 0.8380
    


```python
hist.history
```




    {'loss': [0.465393990278244,
      0.3753565847873688,
      0.3152660131454468,
      0.25309956073760986,
      0.19656561315059662],
     'accuracy': [0.7909919023513794,
      0.8417257070541382,
      0.8684210777282715,
      0.8978998064994812,
      0.9242156147956848],
     'val_loss': [0.39955970644950867,
      0.3504873216152191,
      0.3638642132282257,
      0.38718968629837036,
      0.43269115686416626],
     'val_accuracy': [0.8213028311729431,
      0.8523327708244324,
      0.8556337952613831,
      0.8488116264343262,
      0.8380281925201416]}



# 5. Plotting Performance


```python
fig = plt.figure()
plt.plot(hist.history['loss'], color='teal', label='loss')
plt.plot(hist.history['val_loss'], color='orange', label='val_loss')
fig.suptitle('Loss', fontsize=20)
plt.legend(loc="upper left")
plt.show()
```


    
![png](output_64_0.png)
    



```python
fig = plt.figure()
plt.plot(hist.history['accuracy'], color='teal', label='accuracy')
plt.plot(hist.history['val_accuracy'], color='orange', label='val_accuracy')
fig.suptitle('Accuracy', fontsize=20)
plt.legend(loc="upper left")
plt.show()
```


    
![png](output_65_0.png)
    


# 6. Evaluation


```python
from tensorflow.keras.metrics import Precision, Recall, BinaryAccuracy
```


```python
# metrics
pre = Precision()
re = Recall()
acc = BinaryAccuracy()
```


```python
for batch in test.as_numpy_iterator(): 
    X, y = batch
    yhat = model.predict(X)
    pre.update_state(y, yhat)
    re.update_state(y, yhat)
    acc.update_state(y, yhat)
```

    1/1 [==============================] - 0s 403ms/step
    1/1 [==============================] - 0s 94ms/step
    1/1 [==============================] - 0s 78ms/step
    1/1 [==============================] - 0s 78ms/step
    1/1 [==============================] - 0s 62ms/step
    1/1 [==============================] - 0s 71ms/step
    1/1 [==============================] - 0s 62ms/step
    1/1 [==============================] - 0s 62ms/step
    1/1 [==============================] - 0s 62ms/step
    1/1 [==============================] - 0s 62ms/step
    1/1 [==============================] - 0s 62ms/step
    1/1 [==============================] - 0s 62ms/step
    1/1 [==============================] - 0s 63ms/step
    1/1 [==============================] - 0s 64ms/step
    1/1 [==============================] - 0s 62ms/step
    1/1 [==============================] - 0s 78ms/step
    1/1 [==============================] - 0s 61ms/step
    1/1 [==============================] - 0s 62ms/step
    1/1 [==============================] - 0s 62ms/step
    1/1 [==============================] - 0s 78ms/step
    1/1 [==============================] - 0s 78ms/step
    1/1 [==============================] - 0s 63ms/step
    1/1 [==============================] - 0s 62ms/step
    1/1 [==============================] - 0s 62ms/step
    1/1 [==============================] - 0s 78ms/step
    1/1 [==============================] - 0s 62ms/step
    1/1 [==============================] - 0s 78ms/step
    1/1 [==============================] - 0s 62ms/step
    1/1 [==============================] - 0s 78ms/step
    1/1 [==============================] - 0s 78ms/step
    1/1 [==============================] - 0s 62ms/step
    1/1 [==============================] - 0s 62ms/step
    1/1 [==============================] - 0s 62ms/step
    1/1 [==============================] - 0s 63ms/step
    1/1 [==============================] - 0s 63ms/step
    1/1 [==============================] - 0s 62ms/step
    1/1 [==============================] - 0s 63ms/step
    1/1 [==============================] - 0s 62ms/step
    1/1 [==============================] - 0s 62ms/step
    1/1 [==============================] - 0s 78ms/step
    1/1 [==============================] - 0s 62ms/step
    1/1 [==============================] - 0s 78ms/step
    1/1 [==============================] - 0s 63ms/step
    1/1 [==============================] - 0s 62ms/step
    1/1 [==============================] - 0s 64ms/step
    1/1 [==============================] - 0s 62ms/step
    1/1 [==============================] - 0s 62ms/step
    1/1 [==============================] - 0s 78ms/step
    1/1 [==============================] - 0s 62ms/step
    1/1 [==============================] - 0s 62ms/step
    1/1 [==============================] - 0s 62ms/step
    1/1 [==============================] - 0s 64ms/step
    1/1 [==============================] - 0s 64ms/step
    1/1 [==============================] - 0s 62ms/step
    1/1 [==============================] - 0s 62ms/step
    1/1 [==============================] - 0s 62ms/step
    1/1 [==============================] - 0s 62ms/step
    1/1 [==============================] - 0s 61ms/step
    1/1 [==============================] - 0s 62ms/step
    1/1 [==============================] - 0s 78ms/step
    1/1 [==============================] - 0s 84ms/step
    1/1 [==============================] - 0s 62ms/step
    1/1 [==============================] - 0s 62ms/step
    1/1 [==============================] - 0s 78ms/step
    1/1 [==============================] - 0s 62ms/step
    1/1 [==============================] - 0s 63ms/step
    1/1 [==============================] - 0s 63ms/step
    1/1 [==============================] - 0s 63ms/step
    1/1 [==============================] - 0s 74ms/step
    1/1 [==============================] - 0s 62ms/step
    1/1 [==============================] - 0s 62ms/step
    


```python
print(f'Precision:{pre.result().numpy()}, Recall:{re.result().numpy()}, Accuracy:{acc.result().numpy()}')
```

    Precision:0.7918473482131958, Recall:0.8924731016159058, Accuracy:0.845950722694397
    

# 7. Testing


```python
import cv2
```


```python
# carrots (Recyclable) test
img = cv2.imread('carrot.jpg')
plt.imshow(img)
plt.show()
```


    
![png](output_73_0.png)
    



```python
# color fixing
img = cv2.imread('carrot.jpg')
plt.imshow(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
plt.show()
```


    
![png](output_74_0.png)
    



```python
resize = tf.image.resize(img, (256,256))
plt.imshow(resize.numpy().astype(int))
plt.show()
```


    
![png](output_75_0.png)
    



```python
yhat = model.predict(np.expand_dims(resize/255, 0))
```

    1/1 [==============================] - 2s 2s/step
    


```python
yhat
```




    array([[0.9999999]], dtype=float32)




```python
# correct prediction
# correct - recyclable
```


```python
if yhat <= 0.5: 
    print(f'Predicted class is Recyclable')
else:
    print(f'Predicted class is Non-Recyclable')
```

    Predicted class is Non-Recyclable
    


```python
# grass (Organic) test
img = cv2.imread('daal_nr.jpg')
plt.imshow(img)
plt.show()
```


    
![png](output_80_0.png)
    



```python
# color fixing
img = cv2.imread('daal_nr.jpg')
plt.imshow(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
plt.show()
```


    
![png](output_81_0.png)
    



```python
resize = tf.image.resize(img, (256,256))
plt.imshow(resize.numpy().astype(int))
plt.show()
```


    
![png](output_82_0.png)
    



```python
yhat = model.predict(np.expand_dims(resize/255, 0))
```

    1/1 [==============================] - 0s 36ms/step
    


```python
yhat
```




    array([[0.99986196]], dtype=float32)




```python
# correct prediction
# correct - organic - non recyclable
```


```python
if yhat <= 0.5: 
    print(f'Predicted class is Recyclable')
else:
    print(f'Predicted class is Non-Recyclable')
```

    Predicted class is Non-Recyclable
    

# 8. Saving the model


```python
from tensorflow.keras.models import load_model
```


```python
# .h is a serialization format
model.save(os.path.join('models','wastemodel.h5'))
```


```python
os.path.join('models','wastemodel.h5')
```




    'models\\wastemodel.h5'




```python
new_model = load_model(os.path.join('models','wastemodel.h5'))
```


```python
new_model
```




    <keras.engine.sequential.Sequential at 0x2a2fc577400>




```python
yhatnew = new_model.predict(np.expand_dims(resize/255, 0))
```

    1/1 [==============================] - 0s 91ms/step
    
